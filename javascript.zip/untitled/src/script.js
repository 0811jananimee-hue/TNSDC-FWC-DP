// Sample skills

const skills = ["HTML", "CSS", "JavaScript", "Python", "React"];

// Sample projects

const projects = [

  {

    title: "Personal Blog",

    description: "A blog website built with HTML, CSS, and JavaScript.",

    link: "https://example.com/blog"

  },

  {

    title: "ToDo App",

    description: "A simple ToDo list app using vanilla JS.",

    link: "https://example.com/todo"

  }

];

// Populate skills list

const skillsList = document.getElementById("skills-list");

skills.forEach(skill => {

  const li = document.createElement("li");

  li.textContent = skill;

  skillsList.appendChild(li);

});

// Populate projects

const projectsContainer = document.getElementById("projects-container");

projects.forEach(project => {

  const div = document.createElement("div");

  div.className = "project";

  div.innerHTML = `

    <h3>${project.title}</h3>

    <p>${project.description}</p>

    <a href="${project.link}" target="_blank">View Project</a>

  `;

  projectsContainer.appendChild